<?php include_once('includes/links.php');?>
<?php include_once('includes/sidebar.php');?>
<?php include_once('includes/header.php');?>
<!-- open control start here -->
<?php
	if(isset($_POST['IMG']))
	{
		$file=$_FILES['x']['name'];
		$tmp=$_FILES['x']['tmp_name'];
		$type=$_FILES['x']['type'];
		$size=$_FILES['x']['size'];
		if ($type!="text/plain")
		{
			echo "<script>alert('Invalid type')</script>";
		}
		else
		{
			if ($size > 3145728) 
			{
				echo "<script>alert('Invalid size')</script>";
			}
			else
			{
				$txt=$file;
				$file=fopen("queries/".$txt, "r");
				while (!feof($file))
				{
					$_SESSION['open_ql']=fgets($file);
				}
				fclose($file);

			}
		}
	}
?>

<!-- open control end here -->
	<div class="card w-100 rounded-1 shadow-sm border-0 mb-5" style="background-color: #fff;">
		   		<div class="card-title px-4 py-3 fs-5 text-capitalize fw-light d-flex justify-content-between">
		   			<div class="d-flex">
		   			   <span>Report information</span>
		   			   <a class="btn ms-5" href="?report_des" id="new_query">NEW QUERY</a>
		   			   <!-- <a class="btn ms-5" href="?save_ql"><label for="save">SAVE QUERY</label></a>
		   			   <a class="btn ms-5" href="?open_ql"><label for="myImg">OPEN QUERY</label></a> -->
		   			</div>
		   			
		   		</div>
		   		<?php
		   		if (isset($_GET['report_des'])) 
		   		{
		   			unset($_SESSION['report']);
		   		}



		   		/*save query*/
		   		if (isset($_POST['save_ql']))
		   		{
		   			$file="queries/ql_".date("Y-M-D").".txt";
		   			$_SESSION['ql']=$_POST['ql'];
		   			$file=fopen($file,"w");
		   			$res=fwrite($file, $_SESSION['ql']);
		   			if ($res) 
		   			{
		   				echo "<script>alert('quey saved')</script>";
		   			}
		   			else
		   			{
		   				echo "<script>alert('query not saved')</script>";
		   			}
		   			fclose($file);
		   		}
		   		/*save query end here*/


		   			if (!isset($_SESSION['report'])) 
		   			{
		   		?>
		   			<div class="card-body " id="hide">
		   			<form method="POST">
		   				<textarea onchange="run()" name="ql" class="rounded-4 form-control mb-2 fs-5 rounded-0 bg-light text-muted" required placeholder="copy and paste select report query or type your own"><?php if(isset($_SESSION['open_ql'])){echo $_SESSION['open_ql'];}?></textarea>

		   				<input type="submit" name="ql_sub" value="GO" class="btn btn-dark  float-end rounded-pill w-25  btn-lg" id='submit'>
		   				<input type="submit" name="save_ql" id='save' hidden="">
		   			</form>
		   			</div>


		   					<!-- open file form -->




		   				<?php 
		   				if (isset($_GET['open_ql'])) 
		   		       {
		   					?>
		   					<form method="POST" enctype="multipart/form-data">
		   						<input type="file" name="x" oninput="img()" id="myImg" hidden>
		   						<input type="submit" name="IMG" id='sub_btn' hidden>
		   					</form>
		   					<?php
		   		       }

		   		    ?>



		   		    <!-- open file form end here -->



		   		<?php
		   			}
		         else
		   		{ 
		   			$ql=$_SESSION['report'];
		   			$resualt=mysqli_query($con,$ql); 
		   			if (!$resualt) 
		   			{
		   				die("<b class='h1 p-4 text-center text-danger'>Invalid query</b>");
		   			}
                    $num=mysqli_num_fields($resualt);
                    $show=mysqli_fetch_array($resualt);
                    echo "<script>var new_query = document.getElementById('new_query');new_query.style.opacity='0.03';</script>";
                    ?>
                    <div class="table-responsive">
                    <table width="100%" class=" table-bordered">
                    <?php
                    echo"<tr>";
                    foreach ($show as $key => $value) 
                    {
			           if (!is_int($key)) 
			           {
					           echo "<td class='p-2'>".$key."</td>";
			           }

                    }
                    echo"</tr>";

                    foreach ($show as $key => $value) 
                    {
	                            if (!is_int($key)) 
			                    {
					                    echo "<td>".$value."</td>";
			                    }
                    }
                    echo"</tr>";}
		   		?>

		   		</table>
              </div>
<div class="table-responsive">
<table width="100%" class="table table-striped table-bordered">
<?php 
if (isset($_POST['ql_sub'])) 
{
echo "<script>var close = document.getElementById('hide');close.classList.add('d-none');</script>";
echo "<script>var new_query = document.getElementById('new_query');new_query.style.opacity='0.03';</script>";
$ql=$_POST['ql'];
$resualt=mysqli_query($con,$ql);
if (!$resualt) 
{
  die("<b class='h1 p-4 text-center text-danger'>Invalid query</b>"); 
 }   
$num=mysqli_num_fields($resualt);
$show=mysqli_fetch_array($resualt);
echo"<tr>";
foreach ($show as $key => $value) 
{
			if (!is_int($key)) 
			{
					echo "<td class='p-2'>".$key."</td>";
			}

}
echo"</tr>";

foreach ($show as $key => $value) 
{
	        if (!is_int($key)) 
			{
					echo "<td>".$value."</td>";
			}
}$_SESSION['report']=$ql;
echo"</tr>";}

?>
</table>
<!-- -->	
</div>
<script>
	function run() 
	{
		var btn = document.getElementById('submit');
		btn.click();
	}
	function img()
	{
		var sub_btn = document.getElementById('sub_btn');
		var myImg = document.getElementById('myImg');
		sub_btn.click();
	}
</script>
<?php include_once("includes/footer.php");?>