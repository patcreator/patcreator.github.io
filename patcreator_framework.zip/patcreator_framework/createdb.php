<!DOCTYPE html>
<html>
<head>
	<title>create db</title>
	<link rel="stylesheet" type="text/css" href="css/forms.css">
</head>
<body>
	<div class="back-drop">
		<div class="content">
			<p style="color: #999">Enter the name of your database</p><br>
			<form method="POST" class="search">
				    <input type="submit" name="database_btn" value="&#8981;" id="submit">
					<input type="text" name="db_text" placeholder="search here" required  onchange ='send_input()'>
					
			</form>	
			<?php
			session_start();
			   $con=mysqli_connect("localhost","root","");
				if (isset($_POST['database_btn'])) 
				{
					$db_text=$_POST['db_text'];
					
					$ql=mysqli_query($con,"SHOW DATABASES LIKE '$db_text'");
					if (mysqli_num_rows($ql)==0) 
					{
						echo "<script>alert('database not found');window.history.back()</script>";
					}
					else
					{
						$_SESSION['db']=$db_text;
						header("location:index.php");
					}
				}
			?>
		</div>
	</div>
</body>
<script type="text/javascript">
	function send_input() 
	{
		var x = document.getElementById('submit');
		x.click();
	}
</script>
</html>