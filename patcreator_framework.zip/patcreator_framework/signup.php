<?php
			   session_start();
			   $db=$_SESSION['db'];
			   $con=mysqli_connect("localhost","root","",$db);
				if (isset($_POST['signup'])) 
				{
					$a=$_POST['username'];
					$b=$_POST['password'];
					if (!isset($_POST['check'])) 
					{
						echo("please accept privilages");
					}
					else
					{
						$create="CREATE TABLE IF NOT EXISTS USERS(
						user_id int(11) primary key auto_increment,
						username varchar(100) not null unique,
						password varchar(18) not null
					)";
					$ex_table=mysqli_query($con,$create);
					if ($ex_table) 
					{
							$ql=mysqli_query($con,"SELECT * FROM USERS WHERE username='$a'");
					       if(mysqli_num_rows($ql)>= 1) 
					       {
						     echo "<script>alert('username taken by some one try with new one!');window.location.href='signup.php?exist'</script>";
					        }
					        else
					        {
						        $ins=mysqli_query($con,"INSERT INTO USERS VALUES(NULL,'$a','$b')");
						        if ($ins) 
						        {
						        	
						        	header('location:login.php');
						        }
						        else
						        {
						        	echo "<script>alert('your account is not created! try again');</script>";
						        }
					        }
					}
					else
					{
						echo "table not create!";
					}
					
					}
					
				}
			?>
<!DOCTYPE html>
<html>
<head>
	<title>sign up</title>
</head>
<body>
	<div class="back-drop">
		<div class="content">
			<p style="" class="title">CREATE NEW ACCOUNT<br>
				<small class="small">your database name:<?= $_SESSION['db']?></small></p><br>
			<form method="POST" class="login">
					<input type="text" name="username" placeholder="Enter username" required><br><br>
					<input type="password" name="password" placeholder="Enter password" required  onmouseleave='send_inputt()'><br><br>
					<div class="flex center-between center-items mt-4">
						<small class="small me-2">By checking this box you agree our tearm and privirages<input type="checkbox" name="check" class="ms-2"></small>
					</div><br>
					<div class="flex flex-col txt-center">
						<input type="submit" name="signup" value="CREATE ACCOUNT" id="submit" class="submit txt-center"><br><br>
						<a href="login.php" class="link">Login in your account</a>
					</div>
					
			</form>	
		</div>
	</div>
</body>
<script type="text/javascript">
	function send_input() 
	{
		var x = document.getElementById('submit');
		x.click();
	}
</script>
</html>


  <style type="text/css">
	.content
	{
		margin-top: 100px !important;
		margin: auto;
		width: 400px;
		padding: 10px;
		border: 1px solid rgba(0,0,0,0.1);
	}
</style>