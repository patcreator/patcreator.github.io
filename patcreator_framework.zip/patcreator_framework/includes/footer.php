
		   </section>
		   <footer class="px-4 py-2 text-muted position-fixed bottom-0 w-85 end-0 text-center d-flex justify-content-between bg-white" >2023 &copy; Paywell<span>Design & Developed by Hillsofts technology.</span></footer>
	   </main>
	</div>
	

</body>
<script type="text/javascript">
	function darkmode()
	{
		var b = document.getElementsByTagName('body')[0];
		var f = document.getElementsByTagName('footer')[0];
		var h = document.getElementsByTagName('header')[0];
		var t = document.getElementsByTagName('table')[0];
		var m = document.getElementById('main');
		var c = document.getElementsByClassName('card')[0];
		var formControl = document.getElementsByClassName('form-control');
		var formSelect = document.getElementsByClassName('form-select');
		var btnDark = document.getElementsByClassName('btn-outline-dark');
		for (var i = 0; i <formControl.length; i++)
		{
			formControl[i].classList.toggle("bg-transparent");
		}
		for (var i = 0; i <btnDark.length; i++)
		{
			btnDark[i].classList.toggle("bg-secondary");
		}
		for (var i = 0; i <formSelect.length; i++)
		{
			formSelect[i].classList.toggle("bg-transparent");
			formSelect[i].classList.toggle("text-muted");	
		}
		b.classList.toggle('darkmode');
		f.classList.toggle('darkmode');
		h.classList.toggle('darkmode');
		m.classList.toggle('darkmode');	
		c.classList.toggle('darkmode');
		t.classList.toggle('darkmode');	
		t.classList.toggle('table-mode');		

	}
</script>
</html>