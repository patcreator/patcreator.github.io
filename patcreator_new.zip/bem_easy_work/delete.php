<?php include_once('includes/connection.php');?>
<?php
if (isset($_GET['id']) && isset($_GET['tb'])) 
{
	$tb=$_GET['tb'];
	$id=$_GET['id'];
	$del=mysqli_query($con,"DELETE FROM $tb WHERE id=$id");
	$msg=($del)?'del_ok':'del_no';
	header("location:$tb.php?msg=$msg");	
}
else
{
	header("location:../bem_easy_work/?msg=no-tb-no-id-on-delete");
}
?>