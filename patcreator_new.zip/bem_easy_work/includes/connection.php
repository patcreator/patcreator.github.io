<?php $con=@mysqli_connect('localhost','root','','shop_manager_db') or die("database your select no found<a href=# onclick='window.close()'>click here  to create</a>");
session_start();
$_SESSION['db']='shop_manager_db';

?>
