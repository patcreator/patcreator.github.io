<?php include_once("connection.php");?>
<!DOCTYPE html>
<html>
<head>
	<title>shop</title>
	<!-- <link rel="stylesheet" type="text/css" href="../framework/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../framework/fontawesome-free/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="../framework/fontawesome-6/css/all.min.css"> -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="icon" href="img/logo.png">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>