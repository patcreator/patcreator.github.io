		</section>

		<footer class="flex space-between">
			<?=$_SESSION['site']?>
			<span>
				&copy;2020-2023. All right reserved.
			</span>
		</footer>
	</main>
</body>
</html>