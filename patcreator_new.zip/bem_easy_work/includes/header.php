<?php
if (!isset($_SESSION['username']) || !isset($_SESSION['site'])) 
{
	header("location:login.php");
}
?>
<main>
		<header>
			<div class=" font-family">
				<div style="text-align: center; padding: 20px">WELCOME <?= strtoupper(trim($_SESSION['db'],'_db'))?></div>
<!-- 			<nav>
				<a class="link" href="">home</a>
				<a class="link" href="">about</a>
				<a class="link" href="">add data</a>
				<a class="link" href="">update many</a>
				<a class="link" href="">delete many</a>
				<a class="link" href="">search</a>
			</nav> -->
			</div>
			<div class="flex space-between action padding font-family">
				<span><?php if (isset($_GET['tb'])) 
				{
					echo $_GET['tb'];
				} ?></span>
				<span>
					<?=$_SESSION['username'];?>
					<a href="logout.php" style="color: red;cursor: pointer; text-decoration: none;">logout</a>
				</span>
			</div>
		</header>


		<section class="padding">