	<aside>
		<div class="head flex space-between padding">
			<!-- <span>LOGO</span>
			<button>&#8801;</button> -->
		</div>
		<div class="link-group">
			<a href="../bem_easy_work">Home</a>
			<a href="Report.php">Report</a>
			<a href="Logout.php">Logout</a>
			<?php 
				/*$ql=query('table','link');*/
				$ql=mysqli_query($con,"SHOW TABLES");
				while ($tb=mysqli_fetch_array($ql)) 
				{
					if ($tb[0]!='system_configurations') 
					{
			?>
			<a href="index.php?tb=<?=$tb[0]?>"><?=$tb[0]?></a>
			<?php
					}
			?>
			
			<?php
				}
			 ?>
			
			
		</div>
	</aside>