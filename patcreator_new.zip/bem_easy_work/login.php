<?php
               include_once 'includes/connection.php';
			                  $path=__dir__;
                              $len=strlen($path);
                              $ar=explode('\\', $path);
                              $folder_position=count($ar)-1;
                              $folder=$ar[$folder_position];

				if (isset($_POST['login'])) 
				{
					$a=$_POST['username'];
					$b=$_POST['password'];
						$ql=mysqli_query($con,"SELECT * FROM USERS WHERE username='$a' AND password='$b'");
					if (mysqli_num_rows($ql)==1) 
					{
						$create_tb_ql="CREATE TABLE IF NOT EXISTS `system_configurations` (
                                                   `conf_id` int(11) PRIMARY KEY AUTO_INCREMENT,
                                                   `bg` varchar(100) NOT NULL,
                                                   `fg` varchar(100) NOT NULL,
                                                   `brightness` int(10) NOT NULL,
                                                   `hue` int(11) NOT NULL,
                                                   `logo` varchar(100) NOT NULL,
                                                   `name` varchar(100) NOT NULL,
                                                   `dark_mode` int(2) NOT NULL,
                                                   `aside_view` int(1) NOT NULL,
                                                   `header_position` varchar(100) NOT NULL,
                                                   `footer_position` varchar(100) NOT NULL,
                                                   `main_position` varchar(100) NOT NULL
                                                    ) ENGINE=MyISAM DEFAULT CHARSET=latin1
                                                    ";
                                                    $in="INSERT INTO `system_configurations` (`conf_id`, `bg`, `fg`, `brightness`, `hue`, `logo`, `name`, `dark_mode`, `aside_view`, `header_position`, `footer_position`, `main_position`) VALUES
(1, '#26b9f7', '#000000', 100, 0, 'logo.png', 'clone', 1, 1, 'top', 'bottom', 'center')";
  										
                                     $create_tb=mysqli_query($con,$create_tb_ql);
                                     $ex=mysqli_query($con,$in);
                                     if ($create_tb==1) 
                                     {
                                     	if ($ex) 
                                     	{
                                     		echo "<script>alert('INSERTed');</script>";
                                     	}
                                     	else
                                     	{
                                     		echo "<script>alert('not INSERTed');</script>";
                                     	}
                                     	
						        	echo "<script>alert('table of cong  created');</script>";
                                     }
                                     else
                                     {
                                     	if ($ex) 
                                     	{
                                     		echo "<script>alert('INSERTed');</script>";
                                     	}
                                     	else
                                     	{
                                     		echo "<script>alert('not INSERTed');</script>";
                                     	}
                                     	echo "<script>alert('table of cong not created ');</script>";
                                     }
                                  $_SESSION['site']=$folder;
						          $_SESSION['username']=$a;
						          header("location:index.php");
						        }
         				
						
						
					else
					{
						echo "<script>alert('Incorrect username or password');</script>";
					}
					}
					
			?>
<!DOCTYPE html>
<html>
<head>
	<title>login</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<style type="text/css">
	form
	{
		width: 400px;
		box-shadow: 0 0 10px #678;
		height: 400px;
		margin: auto;
		padding: 40px;
	}
	form input
	{
		width: 100%;
		padding: 10px;
		margin-bottom: 20px;
	}
	form input[type='submit']
	{
		background: #025bee;
		color: white;
		border: none;
		box-shadow: 0 0 10px #789;
		border-radius: 20px;
		cursor: pointer;
	}
	a
	{
		display: block;
		text-align: center;
	}
</style>
<body>
<form method="POST">
	<h1 style="font-size: 40px">LOGIN FORM</h1>
	<div>
		<label>username</label>
		<input name="username" placeholder="username">
	</div>

	<div>
		<label>password</label>
		<input type="password" name="password" placeholder="password">
	</div>

	<div>
		
		<input type="submit" name="login" value="Login">
		<a href="create.php">Create any account</a>
	</div>
</form>
</body>
</html>