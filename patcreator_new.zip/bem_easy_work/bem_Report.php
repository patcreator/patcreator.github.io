<?php include_once('includes/links.php');?>
<?php include_once('includes/sidebar.php');?>
<?php include_once('includes/header.php');?>
			<div>
				<h1>REPORT INFORMATION</h1>
				<br>
				<h3>search in month</h3>
					<form class="flex padding" method="POST">
						<span>from date</span>
						<input type="date" name="d1">
						<span>to date</span>
						<input type="date" name="d2">
						<input type="submit" name="search" value="search">
					</form>
				</p>
			</div>
			<div>
				<table border="1" cellspacing="1" width="100%" rules="all">
					<thead>
						<tr style="background-color: #999;color: white">
							<th>Id</th>
							<th>Client names</th>
							<th>user name</th>
							<th>product name</th>
							<th>product type</th>
							<th>product amount</th>
							<th>created date</th>
							<th colspan="2">Action</th>
						</tr>
					</thead>
					<tbody>
						<?php
						if (isset($_POST['search'])) 
						{
							$d1=$_POST['d1'];
							$d2=$_POST['d2'];
							$sel=mysqli_query($con,"SELECT * FROM buyings b inner join products p on b.product_id=p.id inner join clients c on c.id=b.client_id inner join users u on u.id=b.user_id  WHERE b.created_date BETWEEN '$d1' AND '$d2'");
						}
						else
						{
							$sel=mysqli_query($con,"SELECT * FROM buyings b inner join products p on b.product_id=p.id inner join clients c on c.id=b.client_id inner join users u on u.id=b.user_id");
						}
							if (mysqli_num_rows($sel)==0) 
							{
								echo "<p style='color:red;'>No data found</p>";
							}
							else
							{
								while ($row=mysqli_fetch_array($sel)) 
								{
						?>
						<tr>
							<td><?= $row[0]?></td>
							<td><?= $row['fname'].' '.$row['lname']?></td>
							<td><?= $row['username']?></td>
							<td><?= $row['product_name']?></td>
							<td><?= $row['product_type']?></td>
							<td><?= $row['amount']?></td>
							<td><?= $row[4]?></td>
							<td width="2%"><a class="link" href="delete.php?tb=buyings&id=<?= $row[0]?>">delete</a></td>
							<td width="2%"><a class="link" href="update_buyings.php?id=<?= $row[0]?>">update</a></td>
						</tr>
						<?php
								}
							}
						?>
					</tbody>
				</table>
			</div>

<?php include_once('includes/footer.php');?>