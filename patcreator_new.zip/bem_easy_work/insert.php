<?php include_once('includes/links.php');?>
<?php include_once('includes/sidebar.php');?>
<?php include_once('includes/header.php');?>
<style type="text/css">
	input
	{
		width: 100%;
		padding: 10px;
		border-radius: 10px;
		border: none;
		border: 1px solid #000;
	}
	input[type='submit']
	{
		background: black;
		color: #798;
		font-size: larger;
		width: 90%;
		margin: auto;
		margin-top: 30px;
		display: block;
	}
</style>
		   	<div>
		   		<div>
		   			<h1 class="flex space-between items-center">ADD CLIENT <a onclick="window.history.back()" class="button">Back <span>&#8594;</span></a></h1>
		   			
		   		</div>
		   		<?php
		   				if (isset($_GET['tb'])) 
		   				{
		   					$db=$_SESSION['db'];
		   					 $tb=$_GET['tb'];
		   		?>
		   		<div class="card-body border w-50 p-3">
		   			<form method="POST" action="insert.script.php?tb=<?=$tb?>">
		   			      
		   				

		   				<?php
		   					 $show_col=mysqli_query($con,"SHOW COLUMNS FROM `$tb`");
		   					 $datatype=mysqli_query($con,"SELECT data_type FROM information_schema.columns WHERE table_name='$tb' and table_schema='$db'");
		   					 $i=0;
		   					 $x=0;
		   					 $z=-1;
		   					 $datatype_arr=array();
		   					 	while ($datatype_res=mysqli_fetch_array($datatype)) 
		   					 	{ 
		   					 		$datatype_arr[$i]=$datatype_res[0];
		   					 		$i++;
		   					 	}
		   					 	/*echo "<pre>";
		   					 		print_r($datatype_arr);
		   					 	echo "</pre>";*/

		   					 while ($col=mysqli_fetch_array($show_col)) 
		   					 {
		   					 	switch ($datatype_arr[$x]) {
		   					 		case 'int':
		   					 			$type='number';
		   					 			$required='required';
		   					 			$readonly='';
		   					 			$x++;
		   					 			break;

		   					 		case 'varchar':
		   					 			$type='text';
		   					 			$readonly='';
		   					 			$required='required';
		   					 			$x++;
		   					 			break;
		   					 		case 'date':
		   					 			$type='date';
		   					 			$required='required';
		   					 			$readonly='';
		   					 			$x++;
		   					 			break;
		   					 		case 'year':
		   					 			$type='year';
		   					 			$required='required';
		   					 			$readonly='';
		   					 			$x++;
		   					 			break;
		   					 		case 'time':
		   					 			$type='time';
		   					 			$required='required';
		   					 			$readonly='';
		   					 			$x++;
		   					 			break;
		   					 		case 'timestamp':
		   					 			$type='datetime-local';
		   					 			$required='';
		   					 			$readonly='readonly';
		   					 			$x++;
		   					 			break;

		   					 		default:
		   					 			$type='text';
		   					 			$readonly='';
		   					 			$required='required';
		   					 			$x++;
		   					 			break;
		   					 	}
		   					 	$disabled='';
		   					 	if ($col['Key']=='PRI')
		   					 	{ 
		   					 		$required='';
		   					 		$readonly='readonly';
		   					 		$disabled='disabled';
		   					 	}
		   					?>

                            <div>
		   						<label><?= $col[0]?></label>
		   						<input type="<?= $type;?>" name="value<?=$z++?>" placeholder="enter <?= $col[0]?>" <?= $required.' '.$readonly.' '.$disabled;?>>
		   					</div>
		   					<?php
		   				}
		   				}
		   			    ?>

		   				</div>
		   				<div class="mb-5">
		   					<input type="submit" name="insert" value="ADD <?= $col[0]?>" class="sub-button">
		   				</div>
		   				</div>
		   			</form>
		   		</div>
		   	</div>

<?php include_once("includes/footer.php");?>