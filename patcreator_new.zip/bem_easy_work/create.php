<?php
                 include_once 'includes/connection.php';
				if (isset($_POST['signup'])) 
				{
					$a=$_POST['username'];
					$b=$_POST['password'];
						$create="CREATE TABLE IF NOT EXISTS USERS(
						user_id int(11) primary key auto_increment,
						username varchar(100) not null unique,
						password varchar(18) not null
					)";
					$ex_table=mysqli_query($con,$create);
					if ($ex_table) 
					{
							$ql=mysqli_query($con,"SELECT * FROM USERS WHERE username='$a'");
					       if(mysqli_num_rows($ql)>= 1) 
					       {
						     echo "<script>alert('username taken by some one try with new one!');window.location.href='signup.php?exist'</script>";
					        }
					        else
					        {
						        $ins=mysqli_query($con,"INSERT INTO USERS VALUES(NULL,'$a','$b')");
						        if ($ins) 
						        {
						        	
						        	header('location:login.php');
						        }
						        else
						        {
						        	echo "<script>alert('your account is not created! try again');</script>";
						        }
					        }
					}
					else
					{
						echo "table not create!";
					}
					
					}
			?>

<!DOCTYPE html>
<html>
<head>
	<title>login</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<style type="text/css">
	form
	{
		width: 400px;
		box-shadow: 0 0 10px #678;
		height: 400px;
		margin: auto;
		padding: 40px;
	}
	form input
	{
		width: 100%;
		padding: 10px;
		margin-bottom: 20px;
	}
	form input[type='submit']
	{
		background: #025bee;
		color: white;
		border: none;
		box-shadow: 0 0 10px #789;
		border-radius: 20px;
		cursor: pointer;
	}
	a
	{
		display: block;
		text-align: center;
	}
</style>
<body>
<form method="POST">
	<h1 style="font-size: 40px">SIGNUP FORM</h1>
	<div>
		<label>username</label>
		<input name="username" placeholder="username">
	</div>

	<div>
		<label>password</label>
		<input type="password" name="password" placeholder="password">
	</div>

	<div>
		
		<input type="submit" name="signup" value="Signup">
		<a href="login.php">Have any account login</a>
	</div>
</form>
</body>
</html>