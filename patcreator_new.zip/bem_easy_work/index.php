<?php include_once('includes/links.php');?>
<?php include_once('includes/sidebar.php');?>
<?php include_once('includes/header.php');?>
			<?php 
				if (isset($_GET['tb'])) 
				{
					$tb=$_GET['tb'];
			?>
			<div>
				<h1 class="flex space-between padding"><?=strtoupper($tb);?> INFORMATION <a href="insert.php?tb=<?= $tb;?>" class="button"><span>+</span>ADD</a></h1>
			</div>
			<div>
				<table border="1" cellspacing="1" width="100%" rules="all">
					<thead>
						<tr style="background-color: #999;color: white">
							<?php
		   								$show_col=mysqli_query($con,"SHOW COLUMNS FROM `$tb`");
		   								while ($col=mysqli_fetch_array($show_col)) 
		   								{
		   									if ($col['Key']=='PRI')
		                                      {
			                                      $tb_id=$col[0];
		                                      }
		   							?>
		   								<th><?= $col[0]?></th>
		   							<?php
		   								}
		   							?>
							<th colspan="2">Action</th>
						</tr>
					</thead>
					<tbody>
		   									<?php 
		   					                  if (isset($_POST['search']))
		   					                  {
		   						                $key=$_POST['keyword'];
		   						                $show_row=mysqli_query($con,"SELECT * FROM `$tb` WHERE `$tb_id`='$key'");
		   						                $_SESSION['keyword']=$key;

		   					                  }
		   					                  else
		   					                  {
		   					                  	$show_row=mysqli_query($con,"SELECT * FROM `$tb`");
		   					                  }
		   				                     ?>
		   						<?php
		   								
		   								$num_col=mysqli_num_fields($show_row);
		   		                        while ($row=mysqli_fetch_array($show_row)) 
		   		                        {
		   		                ?>
		   		                <tr>
		   		                	<?php
		   		                	for($i=0;$i < $num_col;$i++)
		   		                	{
		   		                	?>
		   		                	<td><?= $row[$i]?></td>
		   		                	<?php
		   		                	}
		   		                	?>
		   		                	<td width="5%">
		   		                		<a class="link" onclick="return confirm('This record will be deleted forever!')" href="delete.php?tb=<?= $tb?>&id=<?= $row[0]?>">
		   		                		   <!-- <i class="fa fa-trash-alt"></i> -->delete
		   		                	    </a>
		   		                    </td>
		   		                    <td width="5%">
		   		                		<a class="link" href="update.form.php?tb=<?= $tb?>&id=<?= $row[0]?>">
		   		                		   <!-- <i class="fa fa-edit"></i> -->Update
		   		                	    </a>
		   		                    </td>
		   		                </tr>
		   		                <?php
		   		                        }
		   						?>
		   					</tbody>
				</table>
			</div>
			<?php
				}
				else
				{
					echo "<h1 style='font-size:40px;'>WELCOME TO MY WEB PAGE</h1><br><br>
					<p style='font-size:30px'>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			 tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			 quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			 consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			 cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			 proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>";
				}
			 ?>
			 
<?php include_once('includes/footer.php');?>