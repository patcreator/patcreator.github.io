<?php include_once('includes/links.php');?>
<?php include_once('includes/sidebar.php');?>
<?php include_once('includes/header.php');?>
		   				<?php
		   				if (isset($_GET['tb'])) 
		   				{
		   					
		   			    ?>
		   			    <div class="card bg-transparent w-100 rounded-1 shadow-sm border-0 mb-5 p-4" style="background-color: #fff;">
					<div class="card-title px-2 py-3 fs-5 text-capitalize fw-light d-flex justify-content-between">
					<div>
					<?= $tb=$_GET['tb']?>
					information
					</div>

					<div>
					<a href="insert.form.php?tb=<?= $tb?>" class='btn'>ADD NEW</a>
					</div>

					</div>
		   			<div class="table-responsive">
		   				<table class="table-bordered mx-auto w-100">
		   					<thead>
		   						<tr>

		   							<?php
		   							if (isset($_GET['tb'])) 
		   							{
		   								$tb=$_GET['tb'];
		   								$show_col=mysqli_query($con,"SHOW COLUMNS FROM `$tb`");
		   								while ($col=mysqli_fetch_array($show_col)) 
		   								{
		   									if ($col['Key']=='PRI')
		                                      {
			                                      $tb_id=$col[0];
		                                      }
		   							?>
		   								<th class="p-3"><?= $col[0]?></th>
		   							<?php
		   								}
		   							?>
		   							<th colspan="2" class="p-3">Action</th>
		   						</tr>
		   					</thead>
		   					<tbody>
		   									<?php 
		   					                  if (isset($_POST['search']))
		   					                  {
		   						                $key=$_POST['keyword'];
		   						                $show_row=mysqli_query($con,"SELECT * FROM `$tb` WHERE `$tb_id`='$key'");
		   						                $_SESSION['keyword']=$key;

		   					                  }
		   					                  else
		   					                  {
		   					                  	$show_row=mysqli_query($con,"SELECT * FROM `$tb`");
		   					                  }
		   				                     ?>
		   						<?php
		   								
		   								$num_col=mysqli_num_fields($show_row);
		   		                        while ($row=mysqli_fetch_array($show_row)) 
		   		                        {
		   		                ?>
		   		                <tr>
		   		                	<?php
		   		                	for($i=0;$i < $num_col;$i++)
		   		                	{
		   		                	?>
		   		                	<td class="p-3"><?= $row[$i]?></td>
		   		                	<?php
		   		                	}
		   		                	?>
		   		                	<td class="p-3" width="5%">
		   		                		<a class="btn" onclick="return confirm('This record will be deleted forever!')" href="delete.php?tb=<?= $tb?>&id=<?= $row[0]?>">
		   		                		   <!-- <i class="fa fa-trash-alt"></i> -->delete
		   		                	    </a>
		   		                    </td>
		   		                    <td class="p-3" width="5%">
		   		                		<a class="btn" href="update.form.php?tb=<?= $tb?>&id=<?= $row[0]?>">
		   		                		   <!-- <i class="fa fa-edit"></i> -->Update
		   		                	    </a>
		   		                    </td>
		   		                </tr>
		   		                <?php
		   		                        }
		   							}
		   						?>
		   					</tbody>

		   				</table>
		   				
		   			</div>
		   		</div>
		   	</div>
		   			    <?php
		   					
		   					
		   				}
		   				else
		   				{
		   					echo "<h2 class='display-6 m-5  p-5 text-center'>".strtoupper($_SESSION['username'])." WELCOME </h2>";
		   				}

		   				   
		   			?>
	
<script type="text/javascript">
	function search_key() 
	{   
		var search_keywords = document.getElementById('search_keywords');
        search_btn.click();
	}
</script>		   		
<?php include_once("includes/footer.php");?>