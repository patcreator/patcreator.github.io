<?php
include_once 'includes/connection.php';
if (isset($_GET['tb']) && isset($_GET['id'])) 
{
	$tb=$_GET['tb'];
	$id=$_GET['id'];
	$one = 0;
	$sel=mysqli_query($con,"SHOW COLUMNS FROM `$tb`");
	while($row=mysqli_fetch_array($sel))
	{
		if ($one==0) {
			$xtb_id=$row[0];
		}
		if ($row['Key']=='PRI')
		{
			$tb_id=$row[0];
		}
		$one++;
	}
	if (!isset($tb_id)) {
		$tb_id=$xtb_id;
	}
	mysqli_query($con,"SET FOREIGN_KEY_CHECKS = 0;");
	$del=mysqli_query($con,"DELETE FROM `$tb` WHERE `$tb_id`='$id'");
	mysqli_query($con,"SET FOREIGN_KEY_CHECKS = 1;");
	$msg=($del)?'<span class="text-success">Data Deleted</span>':'<span class="text-danger">Data Not Deleted</span>';
	header("location:index.php?tb=$tb&msg=$msg");
}
else
{
	header("location:index.php");
}
?>