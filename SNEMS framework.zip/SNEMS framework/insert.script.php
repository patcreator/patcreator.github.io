<?php
include_once 'includes/connection.php';
if (isset($_GET['tb'])) 
{
	$tb=$_GET['tb'];	
}
else
{
	die('table not found');
}
?>
<?php 
    if (isset($_POST)){
        $myvalue = $mydata = '';
        $data = $_POST;
        // echo "<pre>";
        // print_r($data);
        foreach ($data as $key => $value) {
            $mydata.='`'.$key.'`,';
            $myvalue.='\''.$value.'\',';
        }
        $mydata = substr($mydata, 0, strlen($mydata) - 1);
        $myvalue = substr($myvalue, 0, strlen($myvalue) - 1);
        $query = "INSERT INTO $tb ($mydata) VALUES ($myvalue)";
        $execute = mysqli_query($con,$query);
        if ($execute) {
        	$msg ="<span class='text-success'>data Inserted</span>";
            header("location:index.php?tb=$tb&msg=$msg");
        }
        else
        {
            $msg ="<span class='text-danger'>data not Inserted</span>";
            header("location:index.php?tb=$tb&msg=$msg");
        }

    }
    else
    {
        die("table is missing");
    }
 ?>