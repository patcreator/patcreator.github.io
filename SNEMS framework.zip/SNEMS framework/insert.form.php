<?php include_once('includes/links.php');?>
<?php include_once('includes/sidebar.php');?>
<?php include_once('includes/header.php');?>

		   	<div>
		   		<div class="card-title  px-4 py-3 fs-5 text-capitalize fw-light d-flex justify-content-between w-50 mx-auto" style="color: 2px solid <?= $bg;?>;">
		   			<div>
		   				Add 
		   				<?php
		   				if (isset($_GET['tb'])) 
		   				{
		   					echo $tb=$_GET['tb'];
		   				}

		   				   
		   			?>
		   			 
		   			</div>
		   			<div>
		   				<a onclick="window.history.back()" style="cursor:pointer;">Back</a>
		   			</div>
		   			
		   		</div>
		   		<?php 
    $counter = 0;
    $dataTypes = array();
    $ql = "DESCRIBE $tb";
    $exe = mysqli_query($con,$ql);
    $key = " ";
    while ($row = mysqli_fetch_array($exe)) {
        if ($row['Key']=='PRI') {
            $key = $row['Field'];
            $keyNumber = $counter;
            if ($row['Extra']=='auto_increment') {
                $incr='true';
            }
            else
            {
               $incr='false'; 
            }
        }
        array_push($dataTypes, $row['Type']);
    }
?>
		   		<div class="card-body mx-auto w-50">
		   			    <?php 
            $dtyp=0;
            $fkQl = "SELECT TABLE_NAME, COLUMN_NAME, CONSTRAINT_NAME, REFERENCED_TABLE_NAME, REFERENCED_COLUMN_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA = 'concert' AND REFERENCED_TABLE_NAME IS NOT NULL and TABLE_NAME ='$tb'";
            $fkExe = mysqli_query($con,$fkQl);
            $fk = array();
            while ($fkrow = mysqli_fetch_array($fkExe)) {
                $fk[$fkrow['COLUMN_NAME']] = $fkrow['REFERENCED_TABLE_NAME'].".".$fkrow['REFERENCED_COLUMN_NAME'];
            }
?>
		   			<form method="POST" action="insert.script.php?tb=<?=$tb?>" style="border-top:1px solid <?= $bg;?>;">
		   			    <?php
        $ql = "DESCRIBE $tb";
        $exe = mysqli_query($con,$ql);
        $cols = mysqli_num_fields($exe);
        while ($row = mysqli_fetch_array($exe)) {
                $mykey = $row['Field'];
                if ($mykey==$key and $incr=='true') {
                      $readonly = ' readonly ';
                }
                else{
                    $readonly = ' ';
                }

                if (array_key_exists($mykey, $fk)) {
                    ?>
<div>
<label for="<?= $mykey; ?>"><?= $mykey; ?></label>
<select <?= $readonly; ?> name="<?= $mykey; ?>"  id="<?= $mykey; ?>">
    <optgroup label="<?= $mykey; ?>">
        <?php 
            $xtb = $fk[$mykey];
            $xtb = explode('.', $xtb);
            $keyCol = $xtb[1]; 
            $xtb = $xtb[0];
            $ql2 = "SELECT * FROM $xtb";
            $exe2 = mysqli_query($con,$ql2);
            $num = mysqli_num_fields($exe2);
            
            while($row2 = mysqli_fetch_array($exe2))
            {
              ?>
              <option value="<?= $row2[$keyCol];?>">
                <?= $row2[$keyCol];?> .
                <?php
                for ($i=0; $i < $num; $i++) {
                   if (preg_match('/[a-zA-Z]/', $row2[$i]) ) {
                     echo $row2[$i];
                     break;  
                   }
                }
                ?>   
              </option>
              <?php
            }
         ?>
    </optgroup>
</select>
</div>
                    <?php
                }
                else
                {
                    $step = '';
                    if (str_contains($dataTypes[$dtyp], "int")) {
                     $datatype = 'number';
                    }
                    elseif (str_contains($dataTypes[$dtyp], "DECIMAL")) {
                     $datatype = 'number';
                     $step ='0.1';
                    }
                    elseif (str_contains($dataTypes[$dtyp], "FLOAT")) {
                     $datatype = 'number';
                     $step ='0.111111111';
                    }
                    elseif (str_contains($dataTypes[$dtyp], "DOUBLE")) {
                     $datatype = 'number';
                     $step ='0.11111111111111';
                    }
                    elseif (str_contains($dataTypes[$dtyp], "year")) {
                        $datatype = 'year';
                    }
                    elseif (str_contains($dataTypes[$dtyp], "char")) {
                        $datatype = 'text';
                    }
                    elseif (str_contains($dataTypes[$dtyp], "text")) {
                        $datatype = 'text';
                    }
                    elseif (str_contains($dataTypes[$dtyp], "datetime")) {
                        $datatype = 'datetime-local';
                    }
                    elseif ($dataTypes[$dtyp]== "date") {
                         $datatype = 'date';
                    }
                    elseif ($dataTypes[$dtyp]== "time") {
                         $datatype = 'time';
                    }
                    else
                    {
                         $datatype = 'text';
                    }
                    
                   ?>

<div><label for="<?= $mykey; ?>"><?= $mykey; ?></label>
    <input required <?= $readonly; ?> <?= $step; ?>  type="<?= $datatype; ?>" name="<?= $mykey; ?>" id="<?= $mykey; ?>" placeholder="<?= $mykey; ?>" />
    
</div> 
                   <?php
                   $dtyp++;
                }
        }
    ?>   
<div class="justify-content-end row mt-3">
    <div class="col-12">
        <button type="submit" style="background: <?=$bg;?>;color: <?=$fg;?>">Save data</button>
    </div>
</div>
</form>
		   		</div>
		   	</div>

<?php include_once("includes/footer.php");?>