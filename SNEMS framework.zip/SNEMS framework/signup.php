<?php
			   session_start();
			   if (!isset($_SESSION['db'])) {
			   	echo "<script>window.location.href='createdb.php</script>";
			   }
			   else
			   {
			   	 $db=$_SESSION['db'];
			   }
			   
			   $con=mysqli_connect("localhost","root","",$db);
				if (isset($_POST['signup'])) 
				{
					$a=$_POST['username'];
					$b=$_POST['password'];
					if (!isset($_POST['check'])) 
					{
						echo("please accept privilages");
					}
					else
					{
						$create="CREATE TABLE IF NOT EXISTS __(
						user_id int(11) primary key auto_increment,
						username varchar(100) not null unique,
						password varchar(18) not null
					)";
					$ex_table=mysqli_query($con,$create);
					if ($ex_table) 
					{
							$ql=mysqli_query($con,"SELECT * FROM __ WHERE username='$a'");
					       if(mysqli_num_rows($ql)>= 1) 
					       {
						     echo "<script>alert('username taken by some one try with new one!');window.location.href='signup.php?exist'</script>";
					        }
					        else
					        {
						        $ins=mysqli_query($con,"INSERT INTO __ VALUES(NULL,'$a','$b')");
						        if ($ins) 
						        {
						        	
						        	header('location:login.php');
						        }
						        else
						        {
						        	//echo "<script>alert('your account is not created! try again');</script>";
						        }
					        }
					}
					else
					{
						echo "table not create!";
					}
					
					}
					
				}
				$colors = [1,2,3,4,5,6,7,8,9,0,'a','b','c','d','e','f'];
			?>
<!DOCTYPE html>
<html>
<head>
	<title>sign up</title>
</head>
<body>
	<div class="back-drop">
		<div class="content">
			<p style="" class="title ms-2">CREATE NEW ACCOUNT</p>
			<small style="<?= isset($_SESSION['display'])?'display: none !important;':''; ?>">Refresh the page to change login then click save to save</small>
			<form method="POST" class="login">
					<input type="text" name="username" placeholder="Enter username" required>
					<input type="password" name="password" placeholder="Enter password" required  onmouseleave='send_inputt()'>
					<div class="flex center-between center-items mt-4" style="display:none !important;">
						<small class="small me-2">By checking this box you agree our tearm and privirages<input checked type="checkbox" name="check" class="ms-2"></small>
					</div><br>
					<div class="flex flex-col txt-center">
						<input type="submit" name="signup" value="CREATE ACCOUNT" id="submit" class="submit txt-center"><br><br>
						<a href="login.php" class="link">Login in your account</a>
					</div>
					
			</form>	
		</div>
	</div>
</body>
</html>
<script type="text/javascript">
	function send_input() 
	{
		var x = document.getElementById('submit');
		x.click();
	}
</script>
<style type="text/css">
	<?php 
		if (isset($_SESSION['btn']) && isset($_SESSION['content'])) {
			$btn = $_SESSION['btn'];
			$content = $_SESSION['content'];
		} else {
			$btn = '';
			$content = '';
		}
		
	?>
	a{
		color: black;
		text-decoration: none;
	}
	.content
	{

		margin: auto;
		width: 400px;
		padding: 10px;
		border: 1px solid rgba(0,0,0,0.1);
		font-family: sans-serif;
		<?php 

		if ($content=='') {
			?>
			margin-top: <?php echo $mtop = rand(100,170);?>px !important;
		background-color: #<?php 
		echo $color1 = array_rand($colors);
		echo $color2 = array_rand($colors);
		echo $color3 = array_rand($colors);
		?>;
		border-radius: <?php echo $rad =  rand(0,30);?>px;
		box-shadow: <?php echo $contx = rand(-20,30);?>px <?php echo $conty = rand(-20,30);?>px 10px rgba(0, 0, 0, 0.1);
			<?php
		}
		else{
			echo $content;
		}

		 ?>
	}
	.content form {
	 display: flex;
	 flex-direction: column;
	 padding: 10px;
	}
	.content form *{
	  width: 100%;
	  padding-top: 10px;
	  padding-bottom: 10px;
	}
	.content form input{
		border: 1px solid #000;
		border-radius: 10px;
		margin-bottom: 10px;
	}
	.content form input[type='button'],.content form input[type='submit'],.content form button{
		<?php 
			if ($btn=='') {
		?>
			  background-color: #<?php 
		echo $color1;
		echo $color2;
		echo $color3;
		?>;
	  
	  box-shadow: <?php echo $xshadow = rand(-5,5);?>px <?php echo $yshadow = rand(-5,5);?>px 6px rgba(0, 0, 0, 0.1);
		<?php
			}else{
				echo $btn;
			}
		 ?>
	  font-size: 18px;
	  cursor: pointer;
	}
	.content form input[type='button']:hover,.content form input[type='submit']:hover,.content form button:hover
	{
		
	}
	.x-di{
		display: none !important;
	}
	.px-5{
		margin-left: 30px !important;
	}
	.txt-center{
		text-align: center;
	}
</style>
<a href="login.php?setnew" class="btn downbtn" style="<?= isset($_SESSION['display'])?'display: none !important;':''; ?>">Save color</a>
		<style type="text/css">
			.downbtn{
				margin: auto;
				display: flex;
				position: fixed;
				bottom: 20px;
				 right:20px;
				  padding:40px;border-radius: 50%;height: 30px;width: 30px;align-items: center;justify-content: center;cursor: pointer;box-shadow: 10px 17px 6px rgba(0, 0, 0, 0.1);border: none; background-color:orange;color: white;text-shadow: 3px 3px 3px black;

			}
		</style>
		<?php 
			//unset($_SESSION['btn'],$_SESSION['content'],$_SESSION['display']);
			if (isset($_GET['setnew'])) {
				$_SESSION['btn'] = "box-shadow: $xshadow"."px $yshadow"."px 6px rgba(0, 0, 0, 0.1);background-color: #"."$color1"."$color2"."$color3;";
				$_SESSION['content'] = "margin-top: $mtop"."px !important;background-color: #"."$color1"."$color2"."$color3;
		border-radius: $rad"."px;
		box-shadow: $contx"."px  $conty"."px 10px rgba(0, 0, 0, 0.1);";
		$display = $_SESSION['display'] ='none';
		header('location:signup.php');
			}
		 ?>