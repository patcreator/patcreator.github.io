<?php include_once('includes/links.php');?>
<?php include_once('includes/sidebar.php');?>
<?php include_once('includes/header.php');?>

		   	<div class="w-50 mx-auto">
		   		<div class="card-title  px-4 py-3 fs-5 text-capitalize fw-light d-flex justify-content-between">
		   			<div>
		   				Edit 
		   				<?php
		   				if (isset($_GET['tb']) && isset($_GET['id'])) 
		   				{
		   					echo $tb=$_GET['tb'];
		   					$id=$_GET['id'];
		   					$db = $_SESSION['db'];	
		   				}
	$one = 0;
	$sel=mysqli_query($con,"SHOW COLUMNS FROM `$tb`");
	while($row=mysqli_fetch_array($sel))
	{
		if ($one==0) {
			$xtb_id=$row[0];
		}
		if ($row['Key']=='PRI')
		{
			$tb_id=$row[0];
			$required='';
			$readonly='';
			$disabled='';
			$key = $primary_key=$tb_id;
			$_SESSION['primary_key']=$primary_key;
		}
		$one++;
	}
	if (!isset($tb_id)) {
		$tb_id=$xtb_id;
		$required='';
		$readonly='';
		$disabled='';
		$key = $primary_key=$tb_id;
		$_SESSION['primary_key']=$primary_key;
	}

$required='required';
 			$readonly='';
$datatype=mysqli_query($con,"SELECT data_type FROM information_schema.columns WHERE table_name='$tb' and table_schema='$db'");
		 $i=0;
		 $x=0;
		 $z=-1;
		 $p=0;
		 $datatype_arr=array();
		 	while ($datatype_res=mysqli_fetch_array($datatype)) 
		 	{
		 		$typeme =$datatype_res[0];
		 	switch ($typeme) {
 		case 'int':
 			$datatype_arr[$i] = $type='number';
 			break;
 		case 'varchar':
 			$datatype_arr[$i] = $type='text';
 			break;
 		case 'date':
 			$datatype_arr[$i] = $type='date';
 			break;
 		case 'year':
 			$datatype_arr[$i] = $type='year';
 			break;
 		case 'time':
 			$datatype_arr[$i] = $type='time';
 			break;
 		case 'timestamp':
 			$datatype_arr[$i] = $type='datetime-local';
 			break;
 		default:
 			$datatype_arr[$i] = $type='text';
 			break;
 	}
	$i++;
}
			// echo "<pre>";
			// var_dump($datatype_arr);
			// echo "</pre>";
			// die();
   				   
		   			?>
		   			 
		   			</div>
		   			
		   		</div>
		   		<div class="card-body"> 
		   				<?php 
            $fkQl = "SELECT TABLE_NAME, COLUMN_NAME, CONSTRAINT_NAME, REFERENCED_TABLE_NAME, REFERENCED_COLUMN_NAME FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE WHERE TABLE_SCHEMA = '$db' AND REFERENCED_TABLE_NAME IS NOT NULL and TABLE_NAME ='$tb'";
            $fkExe = mysqli_query($con,$fkQl);
            $fk = array();
            while ($fkrow = mysqli_fetch_array($fkExe)) {
                $fk[$fkrow['COLUMN_NAME']] = $fkrow['REFERENCED_TABLE_NAME'].".".$fkrow['REFERENCED_COLUMN_NAME'];
            }
    // echo "<pre>";
    // print_r($fk);
?>
    <form method="POST" action="update.script.php?tb=<?= $tb; ?>&key=<?= $key; ?>&id=<?= $id; ?>">
    <?php
        $ql = "SELECT * FROM $tb WHERE $key = '$id'";
        $exe = mysqli_query($con,$ql);
        $cols = mysqli_num_fields($exe);
        $row = mysqli_fetch_array($exe);
        foreach ($row as $mykey => $value) {
	        $disabled='';
            if (is_string($mykey)) {
                if ($mykey==$key) {
                      $readonly = ' readonly ';
                }
                else{
                    $readonly = ' ';
                }

                if (array_key_exists($mykey, $fk)) {
                    ?>
<div class="mb-3">
<label for="<?= $mykey; ?>"><?= $mykey; ?></label>
<select <?= $readonly; ?> name="<?= $mykey; ?>"  id="<?= $mykey; ?>" data-toggle="select2">
    <optgroup label="<?= $mykey; ?>">
        <?php 
            $xtb = $fk[$mykey];
            $xtb = explode('.', $xtb);
            $keyCol = $xtb[1]; 
            $xtb = $xtb[0];
            $ql2 = "SELECT * FROM $xtb";
            $exe2 = mysqli_query($con,$ql2);
            $num = mysqli_num_fields($exe2);
            while($row2 = mysqli_fetch_array($exe2))
            {
              ?>
              <option <?= $row2[$keyCol]==$value?' selected ':' ' ?> value="<?= $row2[$keyCol];?>">
                <?= $row2[$keyCol];?> .
                <?php
                for ($i=0; $i < $num; $i++) {
                   if (preg_match('/[a-zA-Z]/', $row2[$i]) ) {
                     echo $row2[$i];
                     break;  
                   }
                }
                ?>   
              </option>
              <?php
            }
         ?>
    </optgroup>
</select>
</div>
                    <?php
                }
                else
                {
                   ?>
<div class="mb-3"> 
               <label for="<?= $mykey; ?>"><?= $mykey; ?></label>
                <input value="<?php echo mysqli_real_escape_string($con,$value); ; ?>" type="<?= $datatype_arr[$x]; ?>" name="<?= $mykey; ?>" id="<?= $mykey; ?>" placeholder="<?= $mykey; ?>" />

</div> 
                   <?php
                   $x++;
                }

    ?>    
    <?php  
            }
        }
        
    ?>   
<div class="justify-content-end row mt-3">
    <div class="col-12">
        <button type="submit" style="background: <?=$bg;?>;color: <?=$fg;?>">Edit</button>
    </div>
</div>
</form>
		   		</div>
		   	</div>

<?php include_once("includes/footer.php");?>