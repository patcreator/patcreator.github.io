<?php 
 if (!isset($_SESSION['username']) || !isset($_SESSION['site'])) 
 {
 	echo "<script>window.location.href='login.php'</script>";
 }
?>
<main id="main" class="
<?php 
if($aside_view=='1')
{
	echo ' ';
}
else
{
	echo '';
}
?>">
		   <header class=" bg-white" >
		   		<div class="d-flex justify-content-end px-2 py-1">
		   			<div style="z-index: 1000;">
								<?php
		   			    			if (isset($_GET['hide'])) 
		   			    			{
		   			    				$_SESSION['hide']='display:none !important';
		   			    				
		   			    			}
		   			    		?>
		   			     <i  role=button class="px-3 me-3 drop" style="<?php if (isset($_SESSION['hide'])) {
		   			     	echo 'opacity:0.01  !important';
		   			     }?>"><a class="btn" href="#">
		   			     	<i class=" fa fa-tools" title="SETTINGS"></i></a>
		   			    	<div class="d-flex bg-white flex-column rounded-3 py-3 content border position-absolute shadow-lg m-settings">
		   			    		
		   			    		<a class="btn text-muted text-start" href="index.php?bg">BG/FG</a>
		   			    		<a class="btn text-muted text-start" href="index.php?hide">Hide</a>
		   			    	</div>
		   			    </i>
		   			</div>
		   			
		   		</div>
		   </header>
		   <div class="message text-center">
		   		<?php 
		   			if (isset($_GET['msg'])) {
		   				echo $_GET['msg'];
		   			}
		   		 ?>
		   </div>
<section class="p-4 mtop" style="color: #444;">
		   	<?php
		   		if (isset($_GET['bg'])) 
		   		{
		   			$url='index.php?bg';
		   			?>
		   			<div class="card w-50 m-auto">
		   				<div class="card-header">
		   					<p class="card-title">Change background color</p>
		   				</div>
		   				<div class="card-body">
		   					<form  method="POST" class="bg-light border m-auto px-4  py-3 rounded-3 shadow-lg" action="index.php">
		   						<div>
		   							<label class="d-block">Select your background or foreground color
		   							</label><small class="text-dark shadow border p-1 bg-dark bg-opacity-10 ">Refresh page to to see changes</small>
		   							<input class="form-control p-2" type="color" name="bgColor" onchange="document.getElementById('color').style.background=this.value;" value="<?= $bg?>">
		   						</div>
		   						<div class="d-flex justify-content-between">
		   							<input class="btn btn-dark mt-3 rounded-pill btn-sm" type="submit" name="bgBtn" value="Background">
		   							<input class="btn btn-dark mt-3 rounded-pill btn-sm" type="submit" name="bgBtn" value="Color">
		   						</div>
		   					</form>
		   				</div>
		   			</div>
		   			<?php
		   		}
		   		if (isset($_POST['bgBtn'])) 
		   		{
		   			$bgBtn=$_POST['bgBtn'];
		   			$bgColor=$_POST['bgColor'];
		   			if ($bgBtn=='Background') 
		   			{
		   				$up=mysqli_query($con,"UPDATE system_configurations SET bg ='$bgColor'");
		   				echo "<script>window.location.href='index.php'</script>";
		   			}
		   			elseif($bgBtn=='Color')
		   			{
		   				$up=mysqli_query($con,"UPDATE system_configurations SET fg ='$bgColor'");
		   				echo "<script>window.location.href='index.php'</script>";
		   			}
		   		}

		   	?>