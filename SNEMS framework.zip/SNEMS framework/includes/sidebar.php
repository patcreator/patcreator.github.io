
<style type="text/css">
		.drop .content
		{
			visibility: hidden !important;
			transition: 100ms ease ;
			margin-left: 0px;
			margin-top: 5px;
		}
		.drop .content:after
		{
			content: '';
			display: block;
			background: white;
			position: absolute;
			height: 15px;
			width: 15px;
			top: -7%;
			left: 50%;
			transform: translateX(-50%) rotate(45deg);
			z-index: 1000000000 !important;
			border-left: 1px solid #ddd;
			border-top: 1px solid #ddd;
		}
		.drop:hover .content
		{
			margin-top:initial; 
			visibility: visible !important;
		}
		.m-settings
		{
			right: 20px;
		}
		form{
			display: flex;
			flex-direction: column;
			padding: 30px;
		}
		form *
		{
			display: block;
			width: 100%;
			border: none;
		}
		form input,form select{
			border: 1px solid black;
			padding: 10px;
			border-radius: 10px;
		}
		form button,input[type='submit']
		{
			display: block;
			width: 100%;
			color: white;
			padding: 10px;
			cursor: pointer;
			border: none;
			border-radius: 20px;
			margin: auto;
		}
</style>
			   	<?php
			   	if (!isset($_SESSION['loggedin'])) {
			   		header('location:login.php');
			   	}
                /*systme configuration*/

                /*conf_id bg fg brightness hue logo name dark_mode aside_view header_position footer_position main_position*/
		        $config=mysqli_query($con,"SELECT * FROM system_configurations");
		        $res=mysqli_fetch_array($config);
		        $conf_id=$res['conf_id'];
                $bg=$res['bg'];
                $fg=$res['fg'];
		   	?>

	<?php 
	if(isset($_GET['des_db'])){session_destroy();header("location:createdb.php");}?>
	<body style="filter: brightness(<?= $brightness.'%'?>) !important;filter: hue-rotate(<?= $hue.'deg'?>) !important;">
	 <div class="cont">
	   <aside class="d-flex justify-content-between" id="aside" style="background-color: <?php echo $bg;?> !important;">
	   	   <div class="home d-flex align-items-center">
	   			<a href="index.php" class='btn fw-bold text-uppercase' style="color: <?= $fg;?> !important">
		   			Home
		   	   </a>
	   	   </div>
		   <div class="buttons d-flex p-3">		   		
		   	<?php 
		   	    $tbs = [];
		   		$show_tb=mysqli_query($con,"SHOW TABLES");
		   		while ($tb=mysqli_fetch_array($show_tb)) 
		   		{
		   		if ($tb[0]=='system_configurations') {
		   			continue;
		   		}
		   		if ($tb[0]=='__') {
		   			continue;
		   		}
		   		else
		   		{
		   			array_push($tbs,$tb[0]);
		   	?>
		   	<a href="index.php?tb=<?= $tb[0]?>" class='btn w-100 text-white text-start fw-bold text-uppercase  letter-spacing-1 hover-white' style="color: <?= $fg;?> !important">
		   			<?= $tb[0]?>
		   		</a>
		   	<?php
		   		}
		   	}
		   	if (!isset($_SESSION['tables'])) {
		   		$_SESSION['tables'] = $tbs;	
		   	}
		   	?>
		   	<a href="report.php" class='btn w-100 text-white text-start fw-light letter-spacing-1 hover-white fw-bold text-uppercase' style="color: <?= $fg;?> !important">
		   			Report
		   	</a>
		   	<a href="logout.php" class='btn w-100 text-white text-start fw-light letter-spacing-1 hover-white fw-bold text-uppercase' style="color: <?= $fg;?> !important">
		   			logout
		   	</a>
		   </div>
	   </aside>