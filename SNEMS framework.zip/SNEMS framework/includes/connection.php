<?php
    session_start(); 
	if (!isset($_SESSION['db'])) 
	{
		die(header('location:createdb.php'));
	}
	else
	{
		$db=$_SESSION['db'];
        $con=@mysqli_connect('localhost','root','',$db) or die('connection fail');
        $_SESSION['db']=$db;
	}
	
?>