 <form method="POST">
 	<div class="d-flex border p-1">
 		<input class="form-control border-0 rounded-0" type="range" value="<?= $hue?>" oninput="hue()" name="enter" id="input" min="0" max="360">
 	<input type="submit" name="save" value="save" class="btn btn-dark border-0 rounded-0">
 	</div>
 	<div class="p-5 text-center" style="background: orange;color: blue;font-size: 30px;">
 		<output id="col"><?=$hue;?></output>
 	</div>
 </form>
 </body>
 <script type="text/javascript">
 	  function hue() {
 		var body=document.getElementsByTagName('body')[0];
		var input=document.getElementById('input');	
		var col=document.getElementById('col');	
 		body.style.filter="hue-rotate("+input.value+"deg)";
 		col.value=input.value;
 	}
 </script>
 </html>
 <?php 
if (isset($_POST['save'])) 
{
	$save=$_POST['enter'];
	$up=mysqli_query($con,"UPDATE system_configurations SET hue ='$save'");
    if ($up) 
    {
     
     echo "<script>window.location.href='index.php'</script>";
    }
    else
    {
      echo "hue not changed";
    }
}

?>