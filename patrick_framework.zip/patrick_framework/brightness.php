
<style>
  #brightness-range { width: 90%; -webkit-appearance: none;
   background: white;
    height: 10px;
     outline: none;
      cursor: pointer;
      box-shadow:  0px 0px 10px #999;
       } #brightness-range::-webkit-slider-thumb { -webkit-appearance: none;
        width: 25px; 
        height: 25px; border-radius: 2%; cursor: pointer; 
        background: white;
        box-shadow:  0px 0px 10px #999;

         }

</style>
<form method="POST">
  <input class="pointer-fixed " type="range" id="brightness-range" min="50" max="100" value="<?= $brightness?>" oninput="fun(this)" name="value">
  <input type="submit" name="light" value="GO" class="btn btn-lg shadow-lg bg-dark bg-opacity-25"> 
</form>
  <?php 
  if (isset($_POST['light'])) 
  {
    $value=$_POST['value'];
    $up=mysqli_query($con,"UPDATE system_configurations SET brightness ='$value'");
    if ($up) 
    {
     
     echo "<script>window.location.href='index.php'</script>";
    }
    else
    {
      echo "brightness not changed";
    }
  }
  ?>
 
 <script> 
 function fun(e) 
 { 
  var body = document.getElementsByTagName('body')[0];
  var val = e.value; 
  /*body.style.filter="brightness("+val+"%)";*/
  body.setAttribute("style", "filter: brightness("+val+"%)"); 
} 
</script>



