<form method="POST" enctype="multipart/form-data">
	<div class="card p-4">
		<img src="img/<?= $logo;?>"  class="rounded-4" style="height: 300px;object-fit: contain; background: black">
	</div>
	<div class="input-group mt-3 rounded-pill shadow-lg p-3">
		<input type="file" name="file" class="form-control" required>
	<input class="btn btn-dark shadow rounded-0 rounded-end float-end " type="submit" name="submitLogo" value="change">
	</div>
</form>
<?php
	if (isset($_POST['submitLogo'])) 
	{
		$name=$_FILES['file']['name'];
		$type=$_FILES['file']['type'];
		$size=$_FILES['file']['size'];
		$size=$size/(1024**2);
		$tmp=$_FILES['file']['tmp_name'];
		$myType=array('image/jpeg','image/jpg','image/png','image/gif','image/bmp','image/ico');
		if (!in_array($type, $myType)) 
		{
			echo "Invalid Image type";	
		}
		else
		{
			if ($size>3) 
			{
				echo "Invalid image type";
			}
			else
			{
				$move=move_uploaded_file($tmp,"img/".$name);
				if ($move) 
				{
					$up=mysqli_query($con,"UPDATE system_configurations SET logo ='$name'");
					if ($up) 
					{
						echo "<script>window.location.href='index.php'</script>";
					}
					else
					{
						echo "Data not updated try again";
					}
				}
				else
				{
					echo "File not uploaded";
				}
			}
		}

	}
?>