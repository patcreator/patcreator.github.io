<?php include_once('includes/links.php');?>
<?php include_once('includes/sidebar.php');?>
<?php include_once('includes/header.php');?>




<div class="d-flex justify-content-between flex-wrap bg-white p-5">
		   				<?php
		   				$tbs=mysqli_query($con,"SHOW TABLES");
		   				while ($tb=mysqli_fetch_array($tbs)) 
		   				{
		   					$table=$tb[0];
		   				?>
		   					<a href="index.php?tb=<?= $table;?>" class="card w-25 bg-white text-muted me-1 mb-2 shadow-lg py-3 dashs">
		   						<div href="index.php?tb=<?= $table?>" class="card-body d-flex flex-column align-items-center">
		   						<?php
		   							$cols=mysqli_query($con,"SELECT * FROM `$table`");
		   							echo"<h3 class='me-2 border p-2 px-3 rounded-circle'>".$num=mysqli_num_rows($cols)."</h3>";

		   						?>
		   						<h6><?= strtoupper($tb[0])?></h6>
		   					   </div>
		   				   </a>
		   				<?php
		   				}
		   				?>
<?php include_once("includes/footer.php");?>