<?php
include_once 'includes/connection.php';
if (isset($_POST['update'])) 
{
	$primary_key=$_SESSION['primary_key'];
	$i=0;
	$j=0;
	$tb=$_GET['tb'];
	$id=$_GET['id'];
	$values='';
	$ql="UPDATE `$tb` SET ";
	 $show_col=mysqli_query($con,"SHOW COLUMNS FROM `$tb` WHERE Field!='$primary_key'");
	 $col_arr=array();
	 while ($show_cols=mysqli_fetch_array($show_col)) 
	 {
	 	$col_arr[$i]=$show_cols[0];
	 	$i++;
	 }
	/*echo "<pre>";
		  print_r($_POST);
	  echo "</pre>";*/
	foreach ($_POST as $key => $value) 
	{ 

		if ($value=='') 
		{
			$value1='now()';
			$value=$col_arr[$j]."='".$value1."', ";
			$values.=$value;
			$j++;
		}
		else
		{
		   if ($key=='update') 
		   {
			   break;
		   }
		   else
		   {   

			   $value=$col_arr[$j]."='".$value."', ";
		       $values.=$value;
		       $j++;
		   }	
		}
		
		
	}
	$end=" WHERE $primary_key=$id";
	$len=strlen($values)-2;
	$values=substr($values,0,$len);

	
	$ql=$ql.$values.$end;

	$exe=mysqli_query($con,$ql);
	$msg=($exe)?'up_ok':'up_no';
	header("location:index.php?tb=$tb&msg=$msg");
	
}
?>