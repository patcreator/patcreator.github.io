<?php
			   session_start();
			   $db=$_SESSION['db'];
			   $con=mysqli_connect("localhost","root","",$db);
				if (isset($_POST['signup'])) 
				{
					$a=$_POST['username'];
					$b=$_POST['password'];
					if (!isset($_POST['check'])) 
					{
						echo("please accept privilages");
					}
					else
					{
						$create="CREATE TABLE IF NOT EXISTS USERS(
						user_id int(11) primary key auto_increment,
						username varchar(100) not null unique,
						password varchar(18) not null
					)";
					$ex_table=mysqli_query($con,$create);
					if ($ex_table) 
					{
							$ql=mysqli_query($con,"SELECT * FROM USERS WHERE username='$a'");
					       if(mysqli_num_rows($ql)>= 1) 
					       {
						     echo "<script>alert('username taken by some one try with new one!');window.location.href='signup.php?exist'</script>";
					        }
					        else
					        {
						        $ins=mysqli_query($con,"INSERT INTO USERS VALUES(NULL,'$a','$b')");
						        if ($ins) 
						        {
						        	
						        	header('location:login.php');
						        }
						        else
						        {
						        	echo "<script>alert('your account is not created! try again');</script>";
						        }
					        }
					}
					else
					{
						echo "table not create!";
					}
					
					}
					
				}
			?>
<!DOCTYPE html>
<html>
<head>
	<title>create db</title>
	<link rel="stylesheet" type="text/css" href="css/forms.css">
	<style type="text/css">
		form.login
		{
			display: flex;
			flex-direction: column;

		}
		form.login  input
		{
			margin-bottom: 8px;
			padding: 15px 10px !important;
			border-bottom: 1px dotted #025bee !important;
			text-align: left;
		}
		form.login input.submit
		{
			background: #025bee !important;
			color: white;
			cursor: pointer;
			margin-top: 10px;

		}
		.title
		{
			color: #666;font-size: 30px;
			border-bottom: 1px solid #eee;
			padding: 10px 4px;
			background: linear-gradient(#efffee 20px,#eee 40px);
		}
		.flex
		{
			display: flex;
		}
		 .flex-col
		 {
		 	flex-direction: column;
		 }
		 .center-between
		 {
		 	justify-content: space-between;
		 }
		 .center-items
		 {
		 	align-items: center;
		 }
		 .link
		 {
		 	text-decoration: none;
		 	color: #123;
		 }
		 .small
		 {
		 	font-size: 13px;
		 }
		 .txt-center
		 {
		 	text-align: center !important;
		 }
		 .me-2
		 {
		 	margin-right: 5px !important;
		 }
		 .ms-2
		 {
		 	margin-left: 18px;
		 }
		 .mt-4
		 {
		 	margin-top: 18px;
		 }
		 .mb-4
		 {
		 	margin-bottom: 18px;
		 }
	</style>
</head>
<body>
	<div class="back-drop">
		<div class="content">
			<p style="" class="title">CREATE NEW ACCOUNT<br>
				<small class="small">your database name:<?= $_SESSION['db']?></small></p><br>
			<form method="POST" class="login">
					<input type="text" name="username" placeholder="Enter username" required>
					<input type="password" name="password" placeholder="Enter password" required  onmouseleave='send_inputt()'>
					<div class="flex center-between center-items mt-4">
						<small class="small me-2">By checking this box you agree our tearm and privirages<input type="checkbox" name="check" class="ms-2"></small>
					</div>
					<div class="flex flex-col txt-center">
						<input type="submit" name="signup" value="CREATE ACCOUNT" id="submit" class="submit txt-center">
						<a href="login.php" class="link">Login in your account</a>
					</div>
					
			</form>	
		</div>
	</div>
</body>
<script type="text/javascript">
	function send_input() 
	{
		var x = document.getElementById('submit');
		x.click();
	}
</script>
</html>

<!-- INSERT INTO `system_configurations` (`conf_id`, `bg`, `fg`, `brightness`, `hue`, `logo`, `name`, `dark_mode`, `aside_view`, `header_position`, `footer_position`, `main_position`) VALUES
(1, '#26b9f7', '#000000', 100, 0, 'Bundesarchiv_Bild_105-DOA0543,_Deutsch-Ostafrika,_Ngoma-Schlagen.jpg', 'clone', 1, 1, 'top', 'bottom', 'center');ALTER TABLE `system_configurations`
  MODIFY `conf_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2 -->