<?php
include_once 'includes/connection.php';
if (isset($_GET['tb']) && isset($_GET['id'])) 
{
	$tb=$_GET['tb'];
	$id=$_GET['id'];
	$sel=mysqli_query($con,"SHOW COLUMNS FROM `$tb`");
	while($row=mysqli_fetch_array($sel))
	{
		if ($row['Key']=='PRI')
		{
			$tb_id=$row[0];
		}
	}

	$del=mysqli_query($con,"DELETE FROM `$tb` WHERE `$tb_id`='$id'");
	$msg=($del)?'ok':'no';
	header("location:index.php?tb=$tb&msg=$msg");
}
else
{
	header("location:index.php");
}
?>