<?php
			   session_start();
			   $db=$_SESSION['db'];
			   $con=mysqli_connect("localhost","root","",$db);
			                  $path=__dir__;
                              $len=strlen($path);
                              $ar=explode('\\', $path);
                              $folder_position=count($ar)-1;
                              $folder=$ar[$folder_position];

				if (isset($_POST['login'])) 
				{
					$a=$_POST['username'];
					$b=$_POST['password'];
					if (!isset($_POST['check'])) 
					{
						echo("<script>alert('please accept privilages')</script>");
					}
					else
					{
						$ql=mysqli_query($con,"SELECT * FROM USERS WHERE username='$a' AND password='$b'");
					if (mysqli_num_rows($ql)==1) 
					{
						$create_tb_ql="CREATE TABLE IF NOT EXISTS `system_configurations` (
                                                   `conf_id` int(11) PRIMARY KEY AUTO_INCREMENT,
                                                   `bg` varchar(100) NOT NULL,
                                                   `fg` varchar(100) NOT NULL,
                                                   `brightness` int(10) NOT NULL,
                                                   `hue` int(11) NOT NULL,
                                                   `logo` varchar(100) NOT NULL,
                                                   `name` varchar(100) NOT NULL,
                                                   `dark_mode` int(2) NOT NULL,
                                                   `aside_view` int(1) NOT NULL,
                                                   `header_position` varchar(100) NOT NULL,
                                                   `footer_position` varchar(100) NOT NULL,
                                                   `main_position` varchar(100) NOT NULL
                                                    ) ENGINE=MyISAM DEFAULT CHARSET=latin1
                                                    ";
                                                    $in="INSERT INTO `system_configurations` (`conf_id`, `bg`, `fg`, `brightness`, `hue`, `logo`, `name`, `dark_mode`, `aside_view`, `header_position`, `footer_position`, `main_position`) VALUES
(1, '#26b9f7', '#000000', 100, 0, 'logo.png', 'clone', 1, 1, 'top', 'bottom', 'center')";
  										
                                     $create_tb=mysqli_query($con,$create_tb_ql);
                                     $ex=mysqli_query($con,$in);
                                     if ($create_tb==1) 
                                     {
                                     	if ($ex) 
                                     	{
                                     		echo "<script>alert('INSERTed');</script>";
                                     	}
                                     	else
                                     	{
                                     		echo "<script>alert('not INSERTed');</script>";
                                     	}
                                     	
						        	echo "<script>alert('table of cong  created');</script>";
                                     }
                                     else
                                     {
                                     	if ($ex) 
                                     	{
                                     		echo "<script>alert('INSERTed');</script>";
                                     	}
                                     	else
                                     	{
                                     		echo "<script>alert('not INSERTed');</script>";
                                     	}
                                     	echo "<script>alert('table of cong not created ');</script>";
                                     }
                                  $_SESSION['site']=$folder;
						          $_SESSION['username']=$a;
						          header("location:index.php");
						        }
         				
						
						
					else
					{
						echo "<script>alert('Incorrect username or password');</script>";
					}
					}
					
				}
			?>
<!DOCTYPE html>
<html>
<head>
	<title>create db</title>
	<link rel="stylesheet" type="text/css" href="css/forms.css">
	<style type="text/css">
		form.login
		{
			display: flex;
			flex-direction: column;

		}
		form.login  input
		{
			margin-bottom: 8px;
			padding: 15px 10px !important;
			border-bottom: 1px dotted #025bee !important;
			text-align: left;
		}
		form.login input.submit
		{
			background: #025bee !important;
			color: white;
			cursor: pointer;
			margin-top: 10px;

		}
		.title
		{
			color: #666;font-size: 30px;
			border-bottom: 1px solid #eee;
			padding: 10px 4px;
			background: linear-gradient(#efffee 20px,#eee 40px);
		}
		.flex
		{
			display: flex;
		}
		 .flex-col
		 {
		 	flex-direction: column;
		 }
		 .center-between
		 {
		 	justify-content: space-between;
		 }
		 .center-items
		 {
		 	align-items: center;
		 }
		 .link
		 {
		 	text-decoration: none;
		 	color: #123;
		 }
		 .small
		 {
		 	font-size: 13px;
		 }
		 .txt-center
		 {
		 	text-align: center !important;
		 }
		 .me-2
		 {
		 	margin-right: 5px !important;
		 }
		 .ms-2
		 {
		 	margin-left: 18px;
		 }
		 .mt-4
		 {
		 	margin-top: 18px;
		 }
		 .mb-4
		 {
		 	margin-bottom: 18px;
		 }
	</style>
</head>
<body>
	<div class="back-drop">
		<div class="content">
			<p style="" class="title">LOGIN INTO ACCOUNT<br>
				<small class="small">your database name:<?= $_SESSION['db']?></small></p><br>
			<form method="POST" class="login">
					<input type="text" name="username" placeholder="Enter username" required>
					<input type="password" name="password" placeholder="Enter password" required  onmouseleave='send_inputt()'>
					<div class="flex center-between center-items mt-4">
						<small class="small me-2">By checking this box you agree our tearm and privirages<input type="checkbox" name="check" class="ms-2"></small>
					</div>
					<div class="flex flex-col txt-center">
						<input type="submit" name="login" value="LOGIN" id="submit" class="submit txt-center">
						<a href="signup.php" class="link">Create any account</a>
					</div>
					
			</form>	
		</div>
	</div>
</body>
<script type="text/javascript">
	function send_input() 
	{
		var x = document.getElementById('submit');
		x.click();
	}
</script>
</html>