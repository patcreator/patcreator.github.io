<?php
include_once 'includes/connection.php';
if (isset($_POST['insert'])) 
{
	$tb=$_GET['tb'];
	$values='';
	$ql="INSERT INTO `$tb` VALUES (NULL";
	/*echo "<pre>";
		  print_r($_POST);
	  echo "</pre>";*/
	foreach ($_POST as $key => $value) 
	{ 

		if ($value=='') 
		{
			$value1='now()';
			$value=','.$value1;
			$values.=$value;
		}
		else
		{
		   if ($key=='insert') 
		   {
			   break;
		   }
		   else
		   {   
			   $value=",'".$value."'";
		       $values.=$value;
		   }	
		}
		
		
	}
	$end=")";
	$ql=$ql.$values.$end;
	$exe=mysqli_query($con,$ql);
	$msg=($exe)?'ins_ok':'ins_no';
	header("location:index.php?tb=$tb&msg=$msg");
	
}
?>