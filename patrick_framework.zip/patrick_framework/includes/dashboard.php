<div class="groups-dashboard mt-5 d-flex flex-wrap">
		   		<?php 
		   		   $show_tb=mysqli_query($con,"SHOW TABLES");
		   			while ($tb=mysqli_fetch_array($show_tb)) 
		   			{
		   				$tb=$tb[0];
		   				$show_rows=mysqli_query($con,"SELECT * FROM `$tb`");
		   				$num=mysqli_num_rows($show_rows);
		   		?>
                 <div class="dashboards rounded-1 shadow-sm bg-white d-flex me-3 mb-3" style="width: 29%">
		   			<div class="p-3 border-end">
		   				<i class="bg-secondary text-white fa fa-table rounded-circle p-3"></i>
		   			</div>
		   			<div class="p-3 d-flex flex-md-column">
		   				<span class="text-muted"><?= $tb?></span>
		   				<span><?=$num?></span>
		   			</div>
		   		</div>
		   		<?php
		   			}
		   		?>
</div>