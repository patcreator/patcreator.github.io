
			   	<?php
                /*systme configuration*/

                /*conf_id bg fg brightness hue logo name dark_mode aside_view header_position footer_position main_position*/
		        $config=mysqli_query($con,"SELECT * FROM system_configurations");
		        $res=mysqli_fetch_array($config);
		        $conf_id=$res['conf_id'];
                $bg=$res['bg'];
                $fg=$res['fg'];
                $brightness=$res['brightness'];
                $hue=$res['hue'];
                $logo=$res['logo'];
                $name=$res['name'];
                $dark_mode=$res['dark_mode'];
                $aside_view=$res['aside_view'];
                $header_position=$res['header_position'];
                $footer_position=$res['footer_position'];
                $main_position=$res['main_position'];
		       /*systme configuration*/
		       $up0="UPDATE system_configurations SET aside_view=0";
		       $up1="UPDATE system_configurations SET aside_view=1";
		   	?>

	<?php 
	if(isset($_GET['des_db'])){session_destroy();header("location:createdb.php");}?>
	<body style="filter: brightness(<?= $brightness.'%'?>) !important;filter: hue-rotate(<?= $hue.'deg'?>) !important;">
	 <div class="container-fluid">
	   <aside class="text-white  h-100 bg-primary border-r overflow-auto 
	         <?php 
	         if(isset($_POST['side'])){
                if($aside_view=='1')
	   			{
	   				echo ' ';
	   				$up=mysqli_query($con,$up0);
	   				header('location:index.php');
	   			}
	   			else
	   			{
	   				echo ' m-off-15';
	   				$up=mysqli_query($con,$up1);
	   				header('location:index.php');
	   			}
	         }
	   			
	   			?>" id="aside" style="background-color: <?php echo $bg;?> !important;">
		   <a href="../<?=$_SESSION['site']?>/">
		   	<div class="mb-3">
		   	  <img src="img/<?=$logo?>" class="logo">
		   </div>
		   </a>
		   <div class="ms-4 mb-3">
		   	   Menu
		   </div>
		   <a href="?des_db" class='btn fs-6 w-100 bg-secondary rounded-0 text-start fw-light letter-spacing-1 hover-white bg-opacity-10 text-white' style="color: <?= $fg;?> !important">
		   			<i class="fa fa-box"></i>
		   			CHANGE DATABASE
		   	</a>
		   <div class="buttons">
		   	<a href="dashboard.php" class='btn w-100 text-white text-start fw-light letter-spacing-1 hover-white' style="color: <?= $fg;?> !important">
		   			<i class="fa fa-table"></i>
		   			Dashboard
		   	</a>
		   	<a href="report.php" class='btn w-100 text-white text-start fw-light letter-spacing-1 hover-white' style="color: <?= $fg;?> !important">
		   			<i class="fa fa-book"></i>
		   			Report
		   	</a>

		   		
		   	<?php 
		   		$show_tb=mysqli_query($con,"SHOW TABLES");
		   		while ($tb=mysqli_fetch_array($show_tb)) 
		   		{
		   	?>	
		   	<?php
		   		switch ($tb[0]) 
		   		{
		   			case 'users':
		   				$icon='fa-users';
		   				break;
		   			case 'classes':
		   				$icon='fa-home';
		   				break;
		   			case 'groups':
		   				$icon='fa-people-group';
		   				break;
		   			case 'levels':
		   				$icon='fa-bacon';
		   				break;
		   			case 'marks':
		   				$icon='fa-newspaper';
		   				break;
		   			case 'modules':
		   				$icon='fa-book-open-reader';
		   				break;
		   			case 'schools':
		   				$icon='fa-warehouse';
		   				break;
		   			case 'terms':
		   				$icon='fa-stopwatch';
		   				break;
		   			case 'trainees':
		   				$icon='fa-users-rays';
		   				break;
		   			case 'trainers':
		   				$icon='fa-user-alt';
		   				break;
		   			case 'users':
		   				$icon='fa-users-between-lines';
		   				break;
		   			
		   			default:
		   				$icon='fa fa-table-columns';
		   				break;
		   		}
		   	?>
		   		<a href="index.php?tb=<?= $tb[0]?>" class='btn w-100 text-white text-start fw-light letter-spacing-1 hover-white' style="color: <?= $fg;?> !important">
		   			<i class="fa <?= $icon?>"></i>
		   			<?= $tb[0]?>
		   		</a>
		   		
		   	<?php
		   		}
		   	?>
		   </div>
	   </aside>