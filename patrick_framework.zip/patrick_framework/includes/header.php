
<?php 
 if (!isset($_SESSION['username']) && !isset($_SESSION['site'])) 
 {
 	echo "<script>window.location.href='login.php'</script>";
 }
?>

<?php 
 if (isset($_GET['logout'])) 
 {
 	unset($_SESSION['username']);
 	header("location:login.php");
 }
?>

<style type="text/css">
	
		.drop .content
		{
			visibility: hidden !important;
			transition: 100ms ease ;
			margin-left: 140px;
			margin-top: 5px;
		}
		.drop .content:after
		{
			content: '';
			display: block;
			background: white;
			position: absolute;
			height: 15px;
			width: 15px;
			top: -7%;
			left: 50%;
			transform: translateX(-50%) rotate(45deg);
			z-index: 1;
			border-left: 1px solid #ddd;
			border-top: 1px solid #ddd;
		}
		.drop:hover .content
		{
			margin-top:initial; 
			visibility: visible !important;
		}
		.m-settings
		{
			margin-left: 210px !important;
		}
		.content:after
		{
			top: -4% !important;
		}
</style>
<main id="main" class="w-85 border-l overflow-auto 
<?php 
				if($aside_view=='1')
	   			{
	   				echo ' ';
	   			}
	   			else
	   			{
	   				echo 'w-100';
	   			}
	   			
	   			?>">
		   <header class="bg-white position-fixed w-in z-index">
		   		<div class="d-flex justify-content-between px-2 py-4 border-bottom">
		   			<div>
		   				<form method="POST">
		   					<input type="submit" name="side" value="side" id="side" hidden>
		   					<label for="side"><i class="fa fa-bars-staggered" role=button></i>	</label>
		   				</form>
		   				
		   				
		   			</div>
		   			
		   			<div>
		   				<i role=button class="px-3 py-1 fa fa-square me-3"></i>
		   			    <i role=button class="px-3 py-1 fa fa-moon me-3" onclick="darkmode()"></i>
		   			    <i  role=button class="px-3 py-1 me-3 drop"><a class="btn" href="#"><i class=" fa fa-user-circle fa-lg" title="users"></i></a>
		   			    	<div class="d-flex bg-white flex-column rounded-3 py-3 content border position-absolute shadow-lg">
		   			    		<a class="btn text-muted text-start" href="?logout">Logout</a>
		   			    	    <a class="btn text-muted text-start" href="#"><?= $_SESSION['username']?></a>
		   			    	</div>
		   			    </i>

		   			     <i  role=button class="px-3 py-1 me-3 drop"><a class="btn" href="#">
		   			     	<i class=" fa fa-tools fa-lg" title="SETTINGS"></i></a>
		   			    	<div class="d-flex bg-white flex-column rounded-3 py-3 content border position-absolute shadow-lg m-settings">
		   			    		<a class="btn text-muted text-start" href="?bg">BG/FG</a>
		   			    	    <a class="btn text-muted text-start" href="?brightness">BRIGHTNESS</a>
		   			    	    <a class="btn text-muted text-start" href="?hue">HUE</a>
		   			    	    <a class="btn text-muted text-start" href="?logo">LOGO</a>
		   			    	    <a class="btn text-muted text-start" href="logic.php">NAME</a>
		   			    	</div>
		   			    </i>
		   			</div>
		   			
		   		</div>
		   		<div class="d-flex justify-content-between px-4 py-2 shadow">
		   			<div>
		   				DASHBOARD
		   			</div>
		   			<div>
		   				<span>Database > </span>
		   				<span class="text-muted"><?= $_SESSION['db']?></span>
		   			</div>
		   		</div>
		   </header>
<section class="p-4 mtop" style="color: #444">
	<div>
		   		Howdy, admin!
		   		<br>
		   		<span class="text-muted small">Welcome back to your dashboard.</span>
		   	</div>
		   	<?php 
		   	$br="<br>";
		   	?>



		   	<?php
		   		if (isset($_GET['bg'])) 
		   		{
		   			$url='index.php?bg';
		   			?>
		   			<div class="card w-50">
		   				<div class="card-header">
		   					<p class="card-title">Change background color</p>
		   				</div>
		   				<div class="card-body">
		   					<form  method="POST" class="bg-light border m-auto px-4  py-3 rounded-3 shadow-lg" action="index.php">
		   						<div>
		   							<label class="d-block">Select your background or foreground color
		   							</label><small class="text-dark shadow border p-1 bg-dark bg-opacity-10 ">Refresh page to to see changes</small>
		   							<input class="form-control p-2" type="color" name="bgColor" onchange="document.getElementById('color').style.background=this.value;" value="<?= $bg?>">
		   						</div>
		   						<div class="d-flex justify-content-between">
		   							<input class="btn btn-dark mt-3 rounded-pill btn-sm" type="submit" name="bgBtn" value="Background">
		   							<input class="btn btn-dark mt-3 rounded-pill btn-sm" type="submit" name="bgBtn" value="Color">
		   						</div>
		   					</form>
		   				</div>
		   			</div>
		   			<?php
		   		}
		   		if (isset($_POST['bgBtn'])) 
		   		{
		   			$bgBtn=$_POST['bgBtn'];
		   			$bgColor=$_POST['bgColor'];
		   			if ($bgBtn=='Background') 
		   			{
		   				$up=mysqli_query($con,"UPDATE system_configurations SET bg ='$bgColor'");
		   			}
		   			elseif($bgBtn=='Color')
		   			{
		   				$up=mysqli_query($con,"UPDATE system_configurations SET fg ='$bgColor'");
		   			}
		   			

		   		}

		   	?>

<?php
 if (isset($_GET['brightness'])) 
 {
 	include_once 'brightness.php';
 }
?>
<?php
 if (isset($_GET['hue'])) 
 {
 	include_once 'hue.php';
 }
?>
<?php
 if (isset($_GET['logo'])) 
 {
 	include_once 'change_logo.php';
 }
?>