<?php include_once('includes/connection.php');?>
<!DOCTYPE html>
<html>
<head>
	<title>FRAME WORK</title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fontawesome-6/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="fontawesome-free/css/all.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
