<!DOCTYPE html>
<html>
<head>
	<title>dashboard</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" type="text/css" href="c:/wamp/www/framework/fontawesome-6/css/all.min.css">
	<style type="text/css">
		*{
			padding: 0;
			margin: 0;
			box-sizing: border-box;
			font-family: arial;
		}
		.wrapper
		{
			display: flex;
			min-height: 100vh;
		}
		aside
		{
			width: 20%;
			position: fixed;
			background: white;
			min-height: 100vh;
			overflow: auto;
		}
		
		main
		{
			background: #def;
			width: 80%;
			overflow: auto;
			flex-grow: 1;
			margin-left: 20%;
		}
		aside div
		{
			padding: 20px 50px;
			cursor: pointer;
			border-radius: 40px 0 0 40px;
		}
		aside div:hover
		{
			background:#def; 
		}
		aside div i{
			color: #444;
		}
		aside div a
		{
			color: #444;
			font-weight: 500;
			margin-left: 5px;
			font-size: 18px;
			text-decoration: none;
		}
		.flex
		{
			display: flex;
		}
		.between
		{
			justify-content: space-between;
		}
		.items
		{
			align-items: center;
		}
		.Logout
		{
			position: absolute;
			bottom: 0;
			width: 100%;
		}
		.padding
		{
			padding: 10px 20px;
		}
		.title
		{
			margin-bottom: 30px;
		}
		.title b{
			font-size: 20px;
			font-family: sans-serif;
		}
		.title i
		{
			color: #666;
		}
		.card
		{
			display: flex;
			flex-direction: column;
			width: 245px;
			padding: 10px 30px;
			background: white;
			flex-grow: 1;
			margin: 10px;
			text-align: center;
			border-radius: 30px;
			box-shadow: 0 0 20px #999;

		}
		.card i
		{
			font-size: 40px;
			margin-bottom: 5px;
		}
		.card h3
		{
			margin-bottom: 10px;
		}
		.card span
		{
			color: #666;
			margin-bottom: 15px;
		}
		.card button
		{
			border-radius: 50px;
			padding: 10px 20px;
			width: 60%;
			margin: auto;
			border: none;
			background: orangered;
			color: white;
			font-size: 13px;
			font-weight: 300;
			text-decoration: none;
			cursor: pointer;
		}
		.container
		{
			display: flex;
		}
		.grow
		{
			flex-grow: 1;
		}
		nav
		{
			text-align: left;
			margin-bottom: 20px;
		}
		nav a
		{
			color: #444;
			margin-left: 20px;
			text-decoration: none;
			font-weight: 500;
			padding: 5px 20px;
		}
		nav a:nth-child(1)
		{
			border-bottom: 2px solid #444;
		}
		.row
		{
			flex-direction: row;
		}
		.container
		{
			padding: 10px 5px; 
			flex-wrap: wrap;
		}
		@media (max-width: 992px)
		{
			aside
			{
				width: 15%;
			}
			aside a
			{
				display: none;
			}
			aside div
			{
				padding: 40px;
			}
			nav a
			{
				display: block;
				margin-left: 0;
			}
		}
		@media (max-width: 640px)
		{
			aside
			{
				width: 20%;
			}
			
			nav a:nth-child(1)
			{
				border: none;
			}
			.card-holder .card
			{
				flex-direction: column-reverse;
				padding: 10px;
			}
			.card-holder .card div
			{
				display: flex;
				flex-direction: column;
			}
			.card-holder .card div img
			{
				margin-left: 0 !important;
			}
		}
		a:active
		{
			margin: 2px 4px;
		}
	</style>
</head>
<body>
	<div class="wrapper">
		<aside>
			<div class="flex items">
				<img src="logo.png" height="25" style="mix-blend-mode: multiply;">
				<a>DASHBOARD</a>
			</div>
			<div>
				<i class="fa fa-home-alt"></i>
			   <a href="Home.php">Home</a>	
			</div>
			<div>
				<i class="fa fa-user"></i>
			   <a href="Profile.php">Profile</a>	
			</div>

			<div>
				<i class="fa fa-wallet"></i>
			   <a href="Wallet.php">Wallet</a>	
			</div>
			<div>
				<i class="fa fa-bar-chart fw-bold"></i>
			   <a href="Analytics.php">Analytics</a>	
			</div>
			<div>
				<i class="fa fa-tasks"></i>
				<a href="Tasks.php">Tasks</a>
			</div>
			<div>
				<i class="fa fa-gear"></i>
				<a href="Settings.php">Settings</a>
			</div>
			<div>
				<i class="fa fa-question-circle"></i>
				<a href="Help.php">Help</a>
			</div>
			<div class="Logout">
				<i class="fa fa-sign-out"></i>
				<a href="Logout.php">Logout</a>
			</div>
		</aside>