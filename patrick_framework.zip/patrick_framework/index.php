<?php include_once('header.php');?>
		<main>
			<div class="flex between padding title">
				<b>Skills</b>
				<i class="fa fa-user-gear"></i>
			</div>
			<div class="container">
				<div class="card">
					 <i class="fa fa-computer"></i>
					 <h3>Web Development</h3>
					 <span>Join over I million Students</span>
					 <button>Get Started</button>
				</div>


				<div class="card">
					 <i class="fa fa-eye"></i>
					 <h3>Web Development</h3>
					 <span>Join over I million Students</span>
					 <button>Get Started</button>
				</div>




				<div class="card">
					 <i class="fab fa-wordpress"></i>
					 <h3>Web Development</h3>
					 <span>Join over I million Students</span>
					 <button>Get Started</button>
				</div>




				<div class="card">
					 <i class="fa fa-table"></i>
					 <h3>Web Development</h3>
					 <span>Join over I million Students</span>
					 <button>Get Started</button>
				</div>
				
			</div>
			<h3 class="padding">My Courses</h3>
			<div class="container">
					<div class="card grow card-holder">
						<nav>
							<a href="#">In progrees</a>
							<a href="#">Explore</a>
							<a href="#">Incoming</a>
							<a href="#">Finished</a>
						</nav>
						<div class="container">
							<div class="card flex items row" style="width: 300px;background: #eee;">
								<div style="text-align: left;">
									<h4>HTML</h4>
									<span>80% progress</span>
									<button style="width: 100%;margin-top: 30px;background: black;border-radius: 8px;">Continue</button>
								</div>
								<div class="flex">
									<img src="html.png" height ="120" style="margin-left:50px;padding: 10px;mix-blend-mode: multiply;">
								</div>
							</div>





<div class="card flex items row" style="width: 300px;background: #eee;">
								<div style="text-align: left;">
									<h4>HTML</h4>
									<span>80% progress</span>
									<button style="width: 100%;margin-top: 30px;background: black;border-radius: 8px;">Continue</button>
								</div>
								<div class="flex">
									<img src="html.png" height ="120" style="margin-left:50px;padding: 10px;mix-blend-mode: multiply;">
								</div>
							</div>







							<div class="card flex items row" style="width: 300px;background: #eee;">
								<div style="text-align: left;">
									<h4>HTML</h4>
									<span>80% progress</span>
									<button style="width: 100%;margin-top: 30px;background: black;border-radius: 8px;">Continue</button>
								</div>
								<div class="flex">
									<img src="html.png" height ="120" style="margin-left:50px;padding: 10px;mix-blend-mode: multiply;">
								</div>
							</div>

						</div>
					</div>
				</div>
		</main>
<?php include_once('footer.php');?>