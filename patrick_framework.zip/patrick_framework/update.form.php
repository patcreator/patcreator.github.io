<?php include_once('includes/links.php');?>
<?php include_once('includes/sidebar.php');?>
<?php include_once('includes/header.php');?>

		   	<div class="card w-100 rounded-1 shadow border-0">
		   		<div class="card-title border-bottom px-4 py-3 fs-5 text-capitalize fw-light d-flex justify-content-between">
		   			<div>
		   				Edit 
		   				<?php
		   				if (isset($_GET['tb']) && isset($_GET['id'])) 
		   				{
		   					echo $tb=$_GET['tb'];
		   					$id=$_GET['id'];	
		   				}

		   				   
		   			?>
		   			 
		   			</div>
		   			<div>
		   				<a onclick="window.history.back()" class='btn btn-outline-dark btn-sm'>Back</a>
		   			</div>
		   			
		   		</div>
		   		<div class="card-body">
		   			<form method="POST" action="update.script.php?tb=<?=$tb?>&id=<?= $id?>">
		   			<div class="row">
		   			      
		   				<?php
		   				if (isset($_GET['tb'])) 
		   				{
		   					 $db=$_SESSION['db'];
		   					 $tb=$_GET['tb'];
		   					 $show_col=mysqli_query($con,"SHOW COLUMNS FROM `$tb`");
		   					 $datatype=mysqli_query($con,"SELECT data_type FROM information_schema.columns WHERE table_name='$tb' and table_schema='$db'");
		   					 $i=0;
		   					 $x=0;
		   					 $z=-1;
		   					 $p=0;
		   					 $datatype_arr=array();
		   					 	while ($datatype_res=mysqli_fetch_array($datatype)) 
		   					 	{ 
		   					 		$datatype_arr[$i]=$datatype_res[0];
		   					 		$i++;
		   					 	}
		   					 	/*echo "<pre>";
		   					 		print_r($datatype_arr);
		   					 	echo "</pre>";*/

		   					 while ($col=mysqli_fetch_array($show_col)) 
		   					 {
		   					 	switch ($datatype_arr[$x]) {
		   					 		case 'int':
		   					 			$type='number';
		   					 			$required='required';
		   					 			$readonly='';
		   					 			$x++;
		   					 			break;

		   					 		case 'varchar':
		   					 			$type='text';
		   					 			$readonly='';
		   					 			$required='required';
		   					 			$x++;
		   					 			break;
		   					 		case 'date':
		   					 			$type='date';
		   					 			$required='required';
		   					 			$readonly='';
		   					 			$x++;
		   					 			break;
		   					 		case 'year':
		   					 			$type='year';
		   					 			$required='required';
		   					 			$readonly='';
		   					 			$x++;
		   					 			break;
		   					 		case 'time':
		   					 			$type='time';
		   					 			$required='required';
		   					 			$readonly='';
		   					 			$x++;
		   					 			break;
		   					 		case 'timestamp':
		   					 			$type='datetime-local';
		   					 			$required='';
		   					 			$readonly='readonly';
		   					 			$x++;
		   					 			break;

		   					 		default:
		   					 			$type='text';
		   					 			$readonly='';
		   					 			$required='required';
		   					 			$x++;
		   					 			break;
		   					 	}
		   					 	$disabled='';
		   					 	if ($col['Key']=='PRI')
		   					 	{ 
		   					 		$required='';
		   					 		$readonly='readonly';
		   					 		$disabled='disabled';
		   					 		$primary_key=$col[0];
		   					 		$_SESSION['primary_key']=$primary_key;
		   					 	}
		   					?>

                            <div class="col-md-6 px-4 mb-2">
		   						<label class="form-text"><?= $col[0]?></label>
		   					<?php
		   						$sel=mysqli_query($con,"SELECT * FROM `$tb` WHERE `$primary_key`='$id'");
		   						while ($this_row=mysqli_fetch_array($sel)) 
		   						{
		   					?>
                             <input value="<?= $this_row[$p++]?>"  type="<?= $type;?>" name="value<?=$z++?>" placeholder="enter <?= $col[0]?>" <?= $required.' '.$readonly.' '.$disabled;?> class="form-control">
		   					<?php
		   						}
		   					?>
		   						
		   					</div>
		   					<?php
		   				}
		   				}
		   			    ?>

		   				</div>
		   				<div class="mb-5">
		   					<input type="submit" name="update" value="EDIT <?= $col[0]?>" class="float-end btn btn-dark rounded-0 ">
		   				</div>
		   				</div>
		   			</form>
		   		</div>
		   	</div>

<?php include_once("includes/footer.php");?>